# Security Policy

## Reporting a vulnerability
Please do not open a public issue for security problems.
Email security@YOUR-DOMAIN.example with a description, steps to reproduce, and the affected page. We aim to acknowledge reports within 5 working days.

## Scope
This repository contains only a static educational website. Do not test systems you do not own or have written permission to test.

## Supported versions
The latest version on the `main` branch.
