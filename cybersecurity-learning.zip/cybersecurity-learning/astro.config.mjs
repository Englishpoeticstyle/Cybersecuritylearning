import { defineConfig } from 'astro/config';

// For a user site (username.github.io), leave base out.
// After you buy a domain, replace the site value.
export default defineConfig({
  site: 'https://YOUR-DOMAIN.example',
  output: 'static',
  trailingSlash: 'ignore',
});
