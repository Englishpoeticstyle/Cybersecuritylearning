# Cyber Security Learning

An educational cybersecurity website in Arabic, French, and English. It is built with Astro and deployed to GitHub Pages.

## Run locally
npm install
npm run validate
npm run dev

## Add a glossary term
1. Add an object to `src/data/glossary.json` with a unique lowercase `id`.
2. Fill in `term`, `definition`, `phonetic`, and `respelling` for en, fr, and ar.
3. Add audio paths and place the files at `public/audio/{lang}/{id}.mp3`.
4. Run `npm run validate`.

Phonetic transcriptions and recordings should be checked by a native speaker before launch.
