import { readFileSync } from 'node:fs';

const MIN_TERMS = Number(process.env.MIN_TERMS ?? 12); // set to 150 before launch
const LANGS = ['en', 'fr', 'ar'];
const FIELDS = ['term', 'definition', 'phonetic', 'respelling'];
const data = JSON.parse(readFileSync('src/data/glossary.json', 'utf8'));
const errors = [];
const ids = new Set();

for (const t of data.terms) {
  if (!/^[a-z0-9-]+$/.test(t.id)) errors.push(`Bad id: ${t.id}`);
  if (ids.has(t.id)) errors.push(`Duplicate id: ${t.id}`);
  ids.add(t.id);
  for (const lang of LANGS) {
    for (const f of FIELDS) {
      if (!t[lang]?.[f]?.trim()) errors.push(`${t.id}: missing ${lang}.${f}`);
    }
    const audio = t.audio?.[lang];
    if (!audio?.startsWith(`/audio/${lang}/`)) errors.push(`${t.id}: bad audio path for ${lang}`);
  }
}
if (data.terms.length < MIN_TERMS) errors.push(`Only ${data.terms.length} terms; need ${MIN_TERMS}`);

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(`Glossary OK: ${data.terms.length} terms, 3 languages.`);
